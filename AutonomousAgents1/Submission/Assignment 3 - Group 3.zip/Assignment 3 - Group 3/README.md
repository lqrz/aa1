Autonomous Agents 1 - Assignment 3 submission. Group 3.
=================
Name - Student Number - Email:
+ Tran Cong Nguyen - 10867481 - cong.tran@student.uva.nl
+ Joost van Doorn - 10805176 - joost.vandoorn@student.uva.nl
+ Roger Wechsler - 10850007 - roger.wechsler@student.uva.nl
+ Lautaro Quiroz - 10849963 - lautaro.quiroz@student.uva.nl

The "board.py" contains the code for the simulator, and "predatorgame.py" has all the algorithms.

The scripts used during experiments can be found in the "scripts" directory. Parameters for the scripts can be edited inside the files.

Note that "ggplot" is needed to reproduce the graphs used in the report. To install use: "pip install ggplot".